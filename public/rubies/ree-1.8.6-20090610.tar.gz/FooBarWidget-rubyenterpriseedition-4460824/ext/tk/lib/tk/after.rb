#
#   tk/after.rb : methods for Tcl/Tk after command
#
#   $Id$
#
require 'tk/timer'

/*
 * $Id$
 * 'OpenSSL for Ruby' project
 * Copyright (C) 2001-2002  Michal Rokos <m.rokos@sh.cvut.cz>
 * All rights reserved.
 */
/*
 * This program is licenced under the same licence as Ruby.
 * (See the file 'LICENCE'.)
 */
#if !defined(_OSSL_VERSION_H_)
#define _OSSL_VERSION_H_

#define OSSL_VERSION "1.0.0"

#endif /* _OSSL_VERSION_H_ */

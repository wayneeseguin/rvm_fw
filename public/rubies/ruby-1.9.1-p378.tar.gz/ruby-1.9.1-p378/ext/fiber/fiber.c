
void ruby_Init_Fiber_as_Coroutine(void);

void
Init_fiber(void)
{
    ruby_Init_Fiber_as_Coroutine();
}

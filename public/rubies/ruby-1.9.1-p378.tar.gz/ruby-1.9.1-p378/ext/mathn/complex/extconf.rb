require "mkmf"

create_makefile "mathn/complex"

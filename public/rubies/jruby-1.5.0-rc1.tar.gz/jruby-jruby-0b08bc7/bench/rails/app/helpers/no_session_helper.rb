module NoSessionHelper
end

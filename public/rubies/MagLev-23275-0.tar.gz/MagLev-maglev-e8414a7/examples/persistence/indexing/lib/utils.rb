class Array
  # Pick an element at random from the array (from the facets library)
  def at_random
    at(rand(size))
  end
end

# First version of the MigrationTest class.  No instances
class MigrationTest
  VERSION = 0

  attr_reader :id
  def initialzie(id)
    @id = id
  end
end


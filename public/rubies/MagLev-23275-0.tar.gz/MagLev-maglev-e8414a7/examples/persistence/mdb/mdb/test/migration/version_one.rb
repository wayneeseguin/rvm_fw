class Data
  attr_reader :x
  def initialize(i)
    @x = i
  end
end

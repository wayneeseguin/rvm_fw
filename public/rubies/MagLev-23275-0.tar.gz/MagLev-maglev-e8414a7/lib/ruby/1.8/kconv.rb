raise NotImplementedError , 'Kconv not supported , there is not a pure Ruby implementation of nkf'

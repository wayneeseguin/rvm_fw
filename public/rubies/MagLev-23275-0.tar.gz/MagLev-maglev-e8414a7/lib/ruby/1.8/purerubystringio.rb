# this file is  purerubystringio.rb
# do nothing because PureRubyStringIO is loaded during bootstrap


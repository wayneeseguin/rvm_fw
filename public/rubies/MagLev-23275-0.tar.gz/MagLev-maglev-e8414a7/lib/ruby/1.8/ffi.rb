# file: ffi.rb
#  FFI is loaded by the Maglev bootstrap , so this file is empty.

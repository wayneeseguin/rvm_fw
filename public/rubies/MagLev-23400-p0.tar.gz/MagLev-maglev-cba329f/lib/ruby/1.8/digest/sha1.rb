# empty file digest/sha1.rb

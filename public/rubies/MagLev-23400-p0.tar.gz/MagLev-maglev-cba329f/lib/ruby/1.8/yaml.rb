#  MagLev uses the ruby code from Psych, plus our own FFI wrapper, to
#  implement YAML.
#
require 'psych'
YAML = Psych

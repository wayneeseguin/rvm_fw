# file:  enumerator.rb
#
#  Enumerable::Enumerator is loaded during bootstrap

module Psych
  class Emitter < Psych::Handler
  end
end

# empty file tempfile.rb  

# standard implementation requires ObjectSpace.define_finalizer
#   which is not supported in Maglev yet.

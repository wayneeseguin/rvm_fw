# This class defines the Rabbit, which just prints an ASCII art
# representation of a rabbit.
class Rabbit
  def inspect
    "\n () ()\n( '.' )\n(\")_(\")\n"
  end
end

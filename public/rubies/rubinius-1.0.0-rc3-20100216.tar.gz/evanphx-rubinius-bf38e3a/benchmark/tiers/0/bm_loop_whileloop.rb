def Bench.run
  i=0
  while i<100_000_000 # benchmark loop 1
    i+=1
  end
end

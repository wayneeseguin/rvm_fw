def Bench.run
  i = 0
  while @should_run
    # string#oct(...)
    raise "string#oct(...) benchmark is not implemented"
    i += 1
  end

  @iterations = i
end

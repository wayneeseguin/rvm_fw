PLEASE READ THESE SOFTWARE LICENSE AGREEMENTS CAREFULLY BEFORE DOWNLOADING
OR USING THIS SOFTWARE. BY DOWNLOADING OR USING THIS SOFTWARE YOU ARE
AGREEING TO BE BOUND BY THE TERMS OF THESE LICENSES. IF YOU DO NOT AGREE
TO THE TERMS OF THESE LICENSES, DO NOT DOWNLOAD OR USE THE SOFTWARE.

Ruby source code written by GemStone Systems, Inc. is licensed under the
MIT license:
   MagLev-MIT-License.txt

The GemStone Virtual Machine and associated binary files and libraries
written by GemStone Systems, Inc. are governed by:
   GemStone-Web-License.txt

Various open source components not written by GemStone Systems, Inc. are 
included in this distribution, and covered by their respective licenses:
   EY-LICENSE.txt - MSpec test execution framework and the RubySpec tests
   MRI-COPYING.txt and MRI-LEGAL.txt - MRI 1.8.6
   Oniguruma-COPYING.txt - Oniguruma Regex
   Rubinius-LICENSE.txt - Rubinius (Ruby Sources only)
   Seaside-MIT-License.txt - Seaside web application framework
   SqueakLicense.txt - Squeak Smalltalk

In all cases where open source components are dual licensed, and one of 
the choices is the GPL, we have chosen to use that software under the
non-GPL license.

class BadCode
  attr_reader :id
  def initialize(id); @id = id end
  def hello();        puts "hi" end
end


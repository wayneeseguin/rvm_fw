class DefaultV1
  CONST_ONE = 1
  CONST_TWO = 2
  attr_accessor :a, :b, :c
  def m1; 1 end
  def m2; 2 end
end


$my.close

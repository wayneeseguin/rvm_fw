$my.query("create database #{$db}")
$created = true
$my.select_db $db

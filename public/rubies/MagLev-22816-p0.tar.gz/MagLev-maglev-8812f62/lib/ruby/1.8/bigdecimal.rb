#
# bigdecimal.rb is loaded during bootstrap

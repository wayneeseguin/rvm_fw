# fcntl.rb, empty file 

# require 'purerubystringio'
#   PureRubyStringIO is loaded during bootstrap

class StringIO < PureRubyStringIO
end


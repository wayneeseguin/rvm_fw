require 'rbyaml'
YAML = RbYAML

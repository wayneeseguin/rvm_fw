def Bench.run
  1_500_000.times { "#{1+1} #{1+1} #{1+1}" }
end

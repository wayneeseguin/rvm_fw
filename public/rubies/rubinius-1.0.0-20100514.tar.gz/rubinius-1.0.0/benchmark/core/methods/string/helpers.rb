module Bench
  def self.random_string
    # Not a realistic string, but it is a random string with
    # 3% punctuation, 5% digits, 8% upper case, 13% space,
    # 71% lower case, shuffled to perfection, then overlayed
    # with 4 \n just to confuse everything.
    "rdnqsp uxq\nhnokjirs\nb c6rlh|4c@jcb av8\nPvunszwijhy lz  kdgy7hlKlR nzqxg\ndqldeg nm-yg vmnb mk gdrn  x"
  end
end

def Bench.run
  i = 0
  while @should_run
    # string#times_op(...)
    raise "string#times_op(...) benchmark is not implemented"
    i += 1
  end

  @iterations = i
end

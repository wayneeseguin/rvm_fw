Bench.run [1_500_000] do |n|
  n.times { "#{1+1} #{1+1} #{1+1}" }
end

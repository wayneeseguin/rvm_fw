require 'rdoc/class_module'

##
# A singleton class

class RDoc::SingleClass < RDoc::ClassModule
end


require 'rdoc'

##
# Namespace for generators

module RDoc::Generator
end


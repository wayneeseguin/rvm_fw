Bench.run [10_000_000, 20_000_000, 30_000_000] do |n|
  n.times { |i| 1 + 1 }
end

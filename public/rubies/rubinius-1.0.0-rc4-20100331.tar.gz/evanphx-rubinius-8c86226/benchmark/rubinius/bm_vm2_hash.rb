h = {:a => 0}
while(h[:a] < 3_000_000)
  h[:a] += 1
end

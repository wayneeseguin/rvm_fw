def Bench.run
  i = 0
  while @should_run
    # string#upcase(...)
    raise "string#upcase(...) benchmark is not implemented"
    i += 1
  end

  @iterations = i
end

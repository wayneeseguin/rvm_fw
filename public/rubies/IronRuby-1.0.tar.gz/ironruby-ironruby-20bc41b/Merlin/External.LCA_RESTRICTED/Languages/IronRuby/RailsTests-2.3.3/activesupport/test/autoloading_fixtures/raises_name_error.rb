class RaisesNameError
  FooBarBaz
end

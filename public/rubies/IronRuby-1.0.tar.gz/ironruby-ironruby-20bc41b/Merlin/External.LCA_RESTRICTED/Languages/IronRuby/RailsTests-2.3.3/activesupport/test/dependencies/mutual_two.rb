$mutual_dependencies_count += 1
require_dependency 'mutual_one.rb'
require_dependency 'mutual_one'
require_dependency 'mutual_one.rb'

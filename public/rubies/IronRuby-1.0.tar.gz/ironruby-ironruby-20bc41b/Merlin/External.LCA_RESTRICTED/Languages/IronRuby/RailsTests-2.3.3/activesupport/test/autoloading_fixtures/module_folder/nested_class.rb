module ModuleFolder
  class NestedClass
  end
end

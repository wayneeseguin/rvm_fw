class A::B
end
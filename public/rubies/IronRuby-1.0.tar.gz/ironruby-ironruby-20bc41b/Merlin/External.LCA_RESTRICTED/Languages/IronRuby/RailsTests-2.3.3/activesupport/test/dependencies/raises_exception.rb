$raises_exception_load_count += 1
raise Exception, 'Loading me failed, so do not add to loaded or history.'
$raises_exception_load_count += 1

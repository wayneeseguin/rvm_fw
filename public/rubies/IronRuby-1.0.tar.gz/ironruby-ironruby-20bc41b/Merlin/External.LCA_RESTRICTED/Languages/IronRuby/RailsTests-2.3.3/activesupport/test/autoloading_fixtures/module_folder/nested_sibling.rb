class ModuleFolder::NestedSibling
end
# used for OracleSynonymTest, see test/synonym_test_oci.rb
#
class Subject < ActiveRecord::Base
end

$counting_loaded_times ||= 0
$counting_loaded_times += 1

module CountingLoader
end

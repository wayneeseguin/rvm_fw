class ModuleFolder::InlineClass
end

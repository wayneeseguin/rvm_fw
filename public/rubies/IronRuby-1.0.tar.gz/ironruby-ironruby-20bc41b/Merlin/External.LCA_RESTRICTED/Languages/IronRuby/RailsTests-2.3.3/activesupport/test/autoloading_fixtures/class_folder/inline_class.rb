class ClassFolder::InlineClass
end

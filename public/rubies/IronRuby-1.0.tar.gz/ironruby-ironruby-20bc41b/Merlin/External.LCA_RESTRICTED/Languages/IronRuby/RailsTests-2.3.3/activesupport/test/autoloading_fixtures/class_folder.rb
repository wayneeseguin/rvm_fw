class ClassFolder
  ConstantInClassFolder = 'indeed'
end

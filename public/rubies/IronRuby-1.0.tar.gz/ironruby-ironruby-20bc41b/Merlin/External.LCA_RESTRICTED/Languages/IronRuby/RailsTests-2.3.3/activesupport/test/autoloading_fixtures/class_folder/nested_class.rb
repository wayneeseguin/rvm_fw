class ClassFolder
  class NestedClass
  end
  
  class SiblingClass
  end
end

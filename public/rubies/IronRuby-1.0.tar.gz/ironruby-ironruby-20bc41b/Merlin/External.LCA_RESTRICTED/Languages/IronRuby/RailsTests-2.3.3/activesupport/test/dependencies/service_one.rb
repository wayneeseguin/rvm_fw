$loaded_service_one ||= 0
$loaded_service_one += 1

class ServiceOne
end
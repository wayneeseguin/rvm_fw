$check_warnings_load_count += 1
$checked_verbose = $VERBOSE

class RaisesNoMethodError
  self.foobar_method_doesnt_exist
end

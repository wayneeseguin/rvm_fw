require 'RMagickDontExistDude'

MultipleConstantFile = 10
SiblingConstant = MultipleConstantFile * 2

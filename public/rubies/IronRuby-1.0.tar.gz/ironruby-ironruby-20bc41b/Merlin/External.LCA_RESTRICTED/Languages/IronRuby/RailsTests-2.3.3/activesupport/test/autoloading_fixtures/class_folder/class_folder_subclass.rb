class ClassFolder::ClassFolderSubclass < ClassFolder
  ConstantInClassFolder
end

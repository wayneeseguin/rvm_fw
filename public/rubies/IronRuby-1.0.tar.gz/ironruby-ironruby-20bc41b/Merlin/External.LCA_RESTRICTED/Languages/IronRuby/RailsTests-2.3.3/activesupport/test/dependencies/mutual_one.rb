$mutual_dependencies_count += 1
require_dependency 'mutual_two'
require_dependency 'mutual_two.rb'
require_dependency 'mutual_two'
